# LX Range — Componenti SIEM (Wazuh / Splunk)

Due playbook con **dropdown di piattaforma**, coerenti con i tuoi prototipi esistenti (metadata header, var prefissate per tool, `assert`, `no_log` sui segreti, risoluzione versione via GitHub API dove possibile).

| Playbook | Dropdown | Cosa fa |
|---|---|---|
| **`install_siem_server`** | `siem_type` = `wazuh` \| `splunk` | Server SIEM all-in-one con pool di regole SOC di base già attivo |
| **`install_siem_agent`** | `siem_type` = `elk` \| `wazuh` \| `splunk` | Agent/forwarder su endpoint Linux o Windows (`siem_agent_os`) |

> L'agent **estende** il tuo `install_siem_agent` esistente: ELK (Elastic Agent + Fleet) e Wazuh restano identici, ho solo aggiunto il ramo **Splunk Universal Forwarder**. Il server ELK resta il tuo `install_security_stack`; qui il server copre Wazuh e Splunk come richiesto.

---

## 1. `install_siem_server` — parametri GUI → JSON

### Selettore (sempre visibile)
- **`siem_type`** — dropdown `wazuh | splunk`. Mostra il set di campi corrispondente.

### Ramo Wazuh (all-in-one: indexer + manager + dashboard)
| Campo GUI | Chiave JSON | Tipo | Default |
|---|---|---|---|
| Profilo deployment | `wazuh_deployment_profile` | select: minimal/small_soc/medium_soc/large_soc | `small_soc` |
| Nome nodo | `wazuh_node_name` | testo | `wazuh01` |
| Nome cluster | `wazuh_cluster_name` | testo | `cyber-range-wazuh` |
| FQDN dashboard | `wazuh_dashboard_public_fqdn` | testo | `localhost` |
| Porta dashboard (HTTPS) | `wazuh_dashboard_port` | testo | `443` |
| Heap indexer | `wazuh_indexer_heap_size` | testo | `4g` |
| Retention (giorni) | `wazuh_retention_days` | testo | `30` |
| Profilo regole | `wazuh_rules_profile` | select: small_company_soc/…_extended | `small_company_soc` |
| Sensibilità regole | `wazuh_rule_sensitivity` | select: low/balanced/high | `balanced` |
| Syslog abilitato | `wazuh_syslog_enabled` | select: yes/no | `yes` |
| Protocollo Syslog | `wazuh_syslog_protocol` | select: udp/tcp | `udp` |
| Porta Syslog | `wazuh_syslog_port` | testo | `514` |
| **Utente admin dashboard** | `wazuh_dashboard_username` | testo | `socadmin` |
| **Password admin dashboard** | `wazuh_dashboard_password` | **secret** | — (runtime/vault) |

### Ramo Splunk (Enterprise, trial 60 gg, all-in-one)
| Campo GUI | Chiave JSON | Tipo | Default |
|---|---|---|---|
| Versione Splunk | `splunk_version` | testo | `9.4.3` |
| **Build hash** | `splunk_build_hash` | testo | — (**obbligatorio**, vedi §3) |
| FQDN pubblico | `splunk_public_fqdn` | testo | `localhost` |
| Porta Splunk Web (HTTPS) | `splunk_web_port` | testo | `8000` |
| Porta ricezione forwarder | `splunk_receiving_port` | testo | `9997` |
| Retention (giorni) | `splunk_retention_days` | testo | `30` |
| Profilo regole | `splunk_rules_profile` | select: small_company_soc/…_extended | `small_company_soc` |
| Sensibilità regole | `splunk_rule_sensitivity` | select: low/balanced/high | `balanced` |
| Syslog abilitato | `splunk_syslog_enabled` | select: yes/no | `yes` |
| Protocollo Syslog | `splunk_syslog_protocol` | select: udp/tcp | `udp` |
| Porta Syslog | `splunk_syslog_port` | testo | `514` |
| **Utente admin Splunk** | `splunk_admin_username` | testo | `socadmin` |
| **Password admin Splunk** | `splunk_admin_password` | **secret** | — (runtime/vault) |

Entrambi i rami: TLS self-signed, Syslog da `0.0.0.0/0`, archivi disattivati, niente firewall/backup/update (come da tue indicazioni).

---

## 2. `install_siem_agent` — parametri GUI → JSON

### Comuni
| Campo | Chiave | Tipo | Default |
|---|---|---|---|
| Piattaforma | `siem_type` | select: elk/wazuh/splunk | `wazuh` |
| OS agent | `siem_agent_os` | select: linux/windows | `linux` |
| IP/FQDN server SIEM | `siem_server_ip` | testo | — (obbligatorio) |
| Versione agent (ELK/Wazuh) | `siem_agent_version` | testo `latest`\|`X.Y.Z` | `latest` |

### Ramo Splunk (Universal Forwarder) — campi aggiunti
| Campo | Chiave | Tipo | Default |
|---|---|---|---|
| Versione UF | `splunk_uf_version` | testo | `9.4.3` |
| **Build hash UF** | `splunk_uf_build_hash` | testo | — (**obbligatorio**) |
| Porta ricezione sul server | `splunk_forward_port` | testo | `9997` |
| Utente admin locale UF | `splunk_uf_admin_username` | testo | `admin` |
| **Password admin locale UF** | `splunk_uf_admin_password` | **secret** | — (runtime/vault) |
| Path log da inoltrare (Linux) | `splunk_uf_monitor_path_linux` | testo | `/var/log` |

(ELK e Wazuh mantengono i loro campi originali: `elk_*`, `wazuh_*`.)
Su Windows il forwarder abilita automaticamente i canali WinEventLog Security/System/Application.

---

## 3. Caveat Splunk (importante)

- **Nessuna API "latest".** Wazuh/ELK risolvono la versione via GitHub API; **Splunk no**. Vanno indicati `splunk_version` **e** `splunk_build_hash` presi **insieme** dalla pagina di download Splunk (`https://www.splunk.com/download`) per la release scelta. Il playbook **fallisce in validazione** se il build hash è vuoto (per evitare download rotti silenziosi). L'hash è lo stesso per tutti i pacchetti (deb/rpm/msi) di una data versione.
- **Licenza.** Installazione in modalità **Enterprise trial 60 giorni** (alerting/correlazione attivi), stesso approccio "Evaluation" già usato per Windows Server 2025. Per uso prolungato serve una licenza Splunk valida.
- **Regole SOC di base.** Sul server Splunk vengono creati come *saved search* schedulati (app `lx_soc_base`) gli equivalenti del pool Wazuh: brute force, PowerShell sospetta, nuovo servizio Windows, log cleared, stop servizio di sicurezza, creazione utente locale, modifica gruppi privilegiati. Sono **starter detection** da affinare sul campo dati reale.

---

## 4. Compatibilità Golden Image (dove ha senso installare un SIEM)

### Server SIEM (`install_siem_server`) → **solo Linux server**
✅ Ubuntu Server 22.04 / 24.04 / 26.04 · Debian 12 / 13 · Rocky Linux 10

❌ **No** su: Alpine (musl — indexer/Splunk non supportati), qualsiasi **Desktop**, **Windows**, e le distro di security **Kali/SIFT/Tsurugi/REMnux/Security Onion** — quelle sono macchine analista/target o SIEM a sé, non su cui installarne un altro.

### Agent / Forwarder (`install_siem_agent`) → endpoint da monitorare
| OS | Wazuh agent | Elastic Agent | Splunk UF |
|---|:--:|:--:|:--:|
| Ubuntu/Debian/Rocky (server & desktop) | ✅ | ✅ | ✅ |
| Windows 10/11/Server 2022/2025 | ✅ | ✅ | ✅ |
| Alpine | ✅ | ✅ | ❌ (musl — bloccato da assert) |
| Kali/Parrot/BlackArch (box offensivi) | ⚠️ solo se lo scenario li vuole monitorati | ⚠️ | ⚠️ |
| SIFT/Tsurugi/REMnux (analyst) | ⚠️ raramente | ⚠️ | ⚠️ |

Regola pratica: l'agent va sui **target da sorvegliare** (server, workstation, DC), non sulle macchine analista/attacker salvo esigenza esplicita dello scenario.

---

## 5. Come lanciarli (segreti a runtime)

```bash
# Server Wazuh
ansible-playbook install_siem_server.yaml -i <inventory> \
  -e @install_siem_server.json \
  -e "wazuh_dashboard_password=<PWD>"

# Server Splunk (ricorda ver+hash)
ansible-playbook install_siem_server.yaml -i <inventory> \
  -e @install_siem_server.json \
  -e "siem_type=splunk splunk_build_hash=<HASH> splunk_admin_password=<PWD>"

# Agent (es. Wazuh su Linux)
ansible-playbook install_siem_agent.yaml -i <inventory> \
  -e @install_siem_agent.json \
  -e "wazuh_enrollment_password=<PWD>"
```
