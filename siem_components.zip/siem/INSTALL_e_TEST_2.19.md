# SIEM — Caricamento su OpenStack e test con control node ansible-core 2.19

Contenuto dello zip (layout a componenti, pronto per il catalogo / `lxr-test`):

```
siem/
├── install_siem_server/       # server all-in-one, dropdown wazuh|splunk
│   ├── install_siem_server.yaml
│   └── install_siem_server.json
├── install_siem_agent/        # agent/forwarder, dropdown elk|wazuh|splunk (Linux+Windows)
│   ├── install_siem_agent.yaml
│   └── install_siem_agent.json
├── install_security_stack/    # esistente, ora con 'splunk' nel dropdown security_tool
│   ├── install_security_stack.yaml
│   └── install_security_stack.json
├── README_SIEM.md             # parametri GUI/JSON, compatibilità, caveat Splunk
└── INSTALL_e_TEST_2.19.md     # questo file
```

> Nota: questi sono **componenti Ansible del catalogo**, non golden image. "Caricarli su OpenStack"
> significa portarli **sul control node** (la VM in OpenStack da cui si lanciano i playbook),
> non su Glance.

---

## 1. Portare i file sul control node

L'accesso al control node è **solo via console noVNC di Horizon** (niente SSH/IP diretto), quindi
il copia-incolla di un file binario non è pratico. Scegli in base a cosa è raggiungibile:

### Opzione A — Git (consigliata, se il control node vede gitlab.cssp.lab)
Il catalogo vive già su GitLab (`new-asset-inventory-2026`). Quindi:

1. Sul tuo PC, scompatta lo zip dentro la tua working copy del repo catalogo, nella cartella
   dei componenti (es. `catalog/` o `components/` — dove stanno gli altri).
2. Commit + push:
   ```bash
   git add siem/
   git commit -m "SIEM: install_siem_server, install_siem_agent (+splunk), install_security_stack (+splunk)"
   git push
   ```
3. Sul control node (console noVNC), nella cartella del catalogo:
   ```bash
   git pull
   ```

### Opzione B — Config-drive / Swift (se non c'è git sul control node)
Carica lo zip come oggetto e scaricalo dal control node:
```bash
# da una macchina con la CLI OpenStack
openstack object create siem-artifacts siem_components.zip
# sul control node
openstack object save siem-artifacts siem_components.zip
unzip siem_components.zip -d /opt/lxrange/catalog/
```

### Opzione C — solo console noVNC, niente rete
Trasferimento base64 a blocchi via console (per file piccoli come questi):
```bash
# sul PC: genera il testo
base64 siem_components.zip > siem_b64.txt   # poi incolla il contenuto nella console:
# sul control node:
cat > siem_b64.txt   # incolla, poi Ctrl-D
base64 -d siem_b64.txt > siem_components.zip
unzip siem_components.zip -d /opt/lxrange/catalog/
```

---

## 2. Prerequisiti sul control node 2.19

```bash
ansible --version        # deve riportare core 2.19.x
# collection necessarie ai playbook:
ansible-galaxy collection install ansible.windows community.general community.docker
```

- `ansible.windows` → serve a `install_siem_agent` (rami Windows).
- `community.general` / `community.docker` → servono a `install_security_stack` (openvas).

---

## 3. Ri-lanciare i test con 2.19

### Con il runner lxr-test (se è il vostro flusso)
```bash
lxr-test discover                                   # deve elencare i 3 nuovi componenti
lxr-test run install_siem_server  --params install_siem_server/install_siem_server.json
lxr-test run install_siem_agent   --params install_siem_agent/install_siem_agent.json
lxr-test run install_security_stack --params install_security_stack/install_security_stack.json
# gli esiti finiscono in runs/<stamp>_<comp>_<target>/
```

### Con ansible-playbook diretto (sempre valido)
I segreti NON sono nei JSON: passali a runtime.
```bash
# Server Wazuh
ansible-playbook install_siem_server/install_siem_server.yaml -i <inventory> \
  -e @install_siem_server/install_siem_server.json \
  -e "wazuh_dashboard_password=<PWD>"

# Server Splunk (ricorda versione + build hash presi dalla pagina download Splunk)
ansible-playbook install_siem_server/install_siem_server.yaml -i <inventory> \
  -e @install_siem_server/install_siem_server.json \
  -e "siem_type=splunk splunk_build_hash=<HASH> splunk_admin_password=<PWD>"

# Agent (es. Splunk UF su Linux)
ansible-playbook install_siem_agent/install_siem_agent.yaml -i <inventory> \
  -e @install_siem_agent/install_siem_agent.json \
  -e "siem_type=splunk splunk_uf_build_hash=<HASH> splunk_uf_admin_password=<PWD>"
```

Verifica rapida della sola sintassi (senza eseguire nulla):
```bash
ansible-playbook --syntax-check install_siem_server/install_siem_server.yaml -i localhost,
ansible-playbook --syntax-check install_siem_agent/install_siem_agent.yaml  -i localhost,
ansible-playbook --syntax-check install_security_stack/install_security_stack.yaml -i localhost,
```

---

## 4. Cose da sapere su 2.19 (per non farsi sorprendere)

1. **Metadata versione.** L'header dice ancora `ansible_core_version: ">=2.12,<2.13"`. È solo un
   commento (Ansible non lo applica), ma sul control node 2.19 è fuorviante: conviene portarlo a
   `">=2.12"` per riflettere il supporto 2.19. Dillo e lo aggiorno su tutti i componenti.
2. **`become_user` non privilegiato (task Splunk "First start").** Su 2.19, quando un task gira come
   `become_user: splunk` da root, Ansible deve poter passare i file temporanei all'utente: se manca
   `acl` sul target può dare *"Failed to set permissions on the temporary files"*. Rimedio:
   `apt install acl` / `dnf install acl` sul target, oppure `-e "ansible_shell_allow_world_readable_temp=true"`.
3. **`ansible.windows` obbligatoria** per i rami Windows dell'agent: senza collection, il playbook
   fallisce al parsing (non è un errore del codice).
4. **Splunk non ha "latest".** `splunk_build_hash` / `splunk_uf_build_hash` sono obbligatori e vanno
   presi INSIEME alla versione dalla pagina download Splunk. Il playbook fallisce in validazione se vuoti.
5. **Idempotenza.** I tre playbook sono idempotenti su re-run (controlli `stat`/`creates`), quindi si
   possono rilanciare senza reinstallare da capo.
